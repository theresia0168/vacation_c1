#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "point.h"

// POINT #1 : 10, 20
// POINT #2 : 30, 40
// DISTANCE : 

int main(int argc, char *argv[]) 
{
	POINT temp;
	POINT *p;
	p = point_new(10);
	
	int i;
	for(i=0; i<2; i++){
		printf("POINT #%d : ", i+1);
		scanf("%d, %d", &temp.x, &temp.y);
		point_set(p+i, temp.x, temp.y);
	}
	
	printf("DISTANCE : %.2f\n", point_distance(p+0, p+1));
	point_destroy(p);
	
	return 0;
}
