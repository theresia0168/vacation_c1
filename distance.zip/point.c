#include<stdio.h>
#include<stdlib.h>
#include<math.h>
#include "point.h"

POINT *point_new(int a)
{
	POINT *r;
	r = (POINT*)malloc(sizeof(POINT)*a);
	return r;
}

void point_destroy(POINT *p)
{
	free(p);
}

void point_set(POINT *p, int a, int b)
{
	p->x=a;
	p->y=b;
}

void point_print(POINT *p)
{
	printf("POINT(x, y) : %d, %d\n", p->x, p->y);
}

void point_fprintf(POINT *p, FILE *f)
{
	fprintf(f, "%d, %d\n", p->x, p->y);
}

void point_printx(POINT *p, FILE *f)
{
	if(f==NULL){
		printf("POINT(x, y) : %d, %d\n", p->x, p->y);
	}
	else{
		fprintf(f, "%d, %d\n", p->x, p->y);
	}
}

double point_distance(POINT *p1, POINT *p2)
{
	return sqrt((p2->x-p1->x)*(p2->x-p1->x)+(p2->y-p1->y)*(p2->y-y1));
}
