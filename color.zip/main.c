#include <stdio.h>
#include <stdlib.h>
#include "color.h"

int main(int argc, char *argv[]) {
	COLOR c1;
	
	float r,g,b;
	printf("Type the rgb code : ");
	scanf("%f, %f, %f", &r, &g, &b);
	
	color_set_rgb(&c1, r, g, b);	// 255 0 0
	color_print_cmyk(&c1);			// 0 1 1 0
	
	return 0;
}
