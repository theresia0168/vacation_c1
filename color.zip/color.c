#include <stdio.h>
#include "color.h"

void color_set_rgb(COLOR *c, int r, int g, int b)
{
	c->r = r;
	c->g = g;
	c->b = b;
}

void color_print_cmyk(COLOR *c)
{
	float buf_r, buf_g, buf_b;
	buf_r = (c->r)/255;
	buf_g = (c->g)/255;
	buf_b = (c->b)/255;
	printf("%f, %f, %f\n", buf_r, buf_g, buf_b);
	float a[3]={buf_r, buf_g, buf_b};
	float max=0;
	int i;
	for(i=0; i<3; i++){
		if(max<a[i]){
			max=a[i];
		}
	}
	printf("%f\n", max);
	
	float K = 1-max;
	float C = (1-buf_r-K)/(1-K);
	float M = (1-buf_g-K)/(1-K);
	float Y = (1-buf_b-K)/(1-K);
	
	printf("(%.2f, %.2f, %.2f, %.2f)\n", C, M, Y, K);
}
